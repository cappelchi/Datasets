#ifndef WINDOWTOSNP
#define WINDOWTOSNP

#include <iostream>
#include "getdata.h"

using namespace std;

void WindowToSnpCalls(ProcessedInput* processedInput, int** windowCalls, int emIterationIndex, double** marginals, int emIteration);

#endif
