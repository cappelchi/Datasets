#ifndef RANDOMFOREST
#define RANDOMFOREST

#include "getdata.h"

using namespace std;

double ** RandomForest(ProcessedInput* proessedInput, double** admClassProbs, int emIteration);

#endif
